# Weather QC — Anomaly Detection System

A web app that uploads AWS (Automatic Weather Station) CSV data, runs automated
quality-control checks (WMO-style flags: pass / suspect / doubtful / wrong),
lets you manually override flags, and download a QC'd CSV.

## Stack
- **Backend:** FastAPI + pandas (`app.py`)
- **Frontend:** HTML/CSS/JS (`index.html`, `style.css`, `script.js`), charts via Chart.js

## Setup

```bash
pip install -r requirements.txt
uvicorn app:app --reload
```

Then open `index.html` in your browser (or serve it via the FastAPI static files,
depending on how `app.py` is wired up).

## Features
- Auto-detects weather columns (Temp, RH, Wind Speed/Dir, MSL, SLP, Rainfall, UV Index)
- Automated anomaly/QC flagging
- Manual flag editing in the data explorer table
- Dashboard with KPIs, monthly trend charts, and flag distribution
- Downloadable QC-flagged CSV output
