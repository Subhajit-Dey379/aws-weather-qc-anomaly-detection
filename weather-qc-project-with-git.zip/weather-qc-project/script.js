// ── STATE ──────────────────────────────────────────────────────────────────
let currentJobId  = null;
let allRows       = [];
let tblColumns    = [];
let filteredRows  = [];
let currentPage   = 0;
let charts        = {};
let fileName      = '';
let manualEdits   = 0;   // how many rows have been manually changed
const PAGE_SIZE   = 20;

// QC columns that are individually editable (not just overall)
const QC_COLS = new Set([
  'qc_MSL','qc_Battery','qc_RF_since_03_UTC','qc_Temp',
  'qc_Min','qc_Max','qc_RH','qc_Wind_Dir','qc_Wind_Speed','qc_SLP','qc_UV'
]);
const PILL_CLS  = {0:'p0',1:'p1',2:'p2',3:'p3'};
const PILL_LBL  = {0:'Pass',1:'Suspect',2:'Doubtful',3:'Wrong'};
const FLAG_CLS  = {0:'f0',1:'f1',2:'f2',3:'f3'};
const FLAG_LBL  = {0:'✅ Pass (0)',1:'⚠️ Suspect (1)',2:'❓ Doubtful (2)',3:'❌ Wrong (3)'};

// ── FILE PICKING ───────────────────────────────────────────────────────────
const fileInput = document.getElementById('file-input');
const dropZone  = document.getElementById('drop-zone');
document.getElementById('choose-btn').addEventListener('click', e => { e.stopPropagation(); fileInput.click(); });
dropZone.addEventListener('click', e => { if(e.target.id !== 'choose-btn') fileInput.click(); });
fileInput.addEventListener('change', () => { if(fileInput.files.length) handleFile(fileInput.files[0]); });
dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('drag'); });
dropZone.addEventListener('dragleave', ()  => dropZone.classList.remove('drag'));
dropZone.addEventListener('drop', e => { e.preventDefault(); dropZone.classList.remove('drag'); if(e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]); });

function handleFile(file) {
  if (!file.name.toLowerCase().endsWith('.csv')) { showToast('Please upload a .csv file', true); return; }
  fileName = file.name.replace(/\.csv$/i, '');
  document.getElementById('upload-section').style.display = 'none';
  document.getElementById('progress-section').style.display = 'block';
  uploadToBackend(file);
}

// ── UPLOAD ─────────────────────────────────────────────────────────────────
function stepProgress(step, pct) {
  for (let i = 1; i <= 6; i++) {
    const el = document.getElementById('s' + i);
    if (i < step) { el.classList.remove('active'); el.classList.add('done'); el.querySelector('.step-icon').textContent = '✓'; }
    else if (i === step) el.classList.add('active');
  }
  document.getElementById('prog-bar').style.width = pct + '%';
}

async function uploadToBackend(file) {
  stepProgress(1, 15);
  const fd = new FormData();
  fd.append('file', file);
  try {
    await delay(200); stepProgress(2, 30);
    const resp = await fetch('/api/analyze', { method:'POST', body:fd });
    await delay(150); stepProgress(4, 65);
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({detail:'Server error ' + resp.status}));
      throw new Error(err.detail || 'Server error');
    }
    const data = await resp.json();
    await delay(150); stepProgress(6, 100);
    for (let i = 1; i <= 6; i++) {
      const el = document.getElementById('s' + i);
      el.classList.remove('active'); el.classList.add('done');
      el.querySelector('.step-icon').textContent = '✓';
    }
    await delay(350);
    currentJobId = data.job_id;
    allRows      = data.rows;
    tblColumns   = data.columns;
    manualEdits  = 0;
    document.getElementById('progress-section').style.display = 'none';
    buildDashboard(data.dashboard);
    buildTable();
    document.getElementById('dashboard').style.display = 'block';
    showToast('✓ QC complete — ' + data.dashboard.total.toLocaleString() + ' records processed');
  } catch(e) {
    document.getElementById('progress-section').style.display = 'none';
    document.getElementById('upload-section').style.display = 'flex';
    showToast('✗ ' + e.message, true);
  }
}

// ── DASHBOARD ──────────────────────────────────────────────────────────────
function buildDashboard(d) {
  document.getElementById('dash-title').textContent = '🌦 ' + d.station_name + ' — Weather QC Dashboard';
  setText('k-total', d.total.toLocaleString()); setText('k-period', d.period);
  setText('k-pass',  d.pass.toLocaleString());   setText('k-pass-p',  pct(d.pass,  d.total));
  setText('k-susp',  d.suspect.toLocaleString()); setText('k-susp-p',  pct(d.suspect, d.total));
  setText('k-doubt', d.doubtful.toLocaleString());setText('k-doubt-p', pct(d.doubtful,d.total));
  setText('k-wrong', d.wrong.toLocaleString());  setText('k-wrong-p', pct(d.wrong, d.total));
  setText('k-worst', d.worst_param);
  setText('k-worst-p', pct(d.worst_param_count, d.total) + ' flagged');
  buildMonthlyChart(d.monthly); buildDonut(d.pass,d.suspect,d.doubtful,d.wrong);
  buildQCMonthChart(d.monthly); buildFlagBars(d.param_flags, d.total);
  buildHotspots(d.param_flags, d.total); buildRecs();
  const ps = document.getElementById('param-filter');
  ps.innerHTML = '<option value="">All parameters</option>';
  Object.keys(d.param_flags).forEach(p => { const o=document.createElement('option'); o.value=p; o.textContent=p; ps.appendChild(o); });
}

function buildMonthlyChart(monthly) {
  const ctx = document.getElementById('c-monthly');
  if (charts.monthly) charts.monthly.destroy();
  charts.monthly = new Chart(ctx,{type:'bar',data:{labels:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],datasets:[
    {label:'Temp',data:monthly.map(m=>m.avg_temp),backgroundColor:'#4fb6f044',borderColor:'#4fb6f0',borderWidth:1.5,yAxisID:'y'},
    {label:'RH',data:monthly.map(m=>m.avg_rh),type:'line',borderColor:'#f2a93c',backgroundColor:'#f2a93c20',borderWidth:2,pointRadius:3,fill:true,tension:0.3,yAxisID:'y1'}
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},
    scales:{x:{ticks:{color:'#6c84a8',font:{size:10}},grid:{color:'#1f335855'}},y:{ticks:{color:'#6c84a8',font:{size:10},callback:v=>v+'°'},grid:{color:'#1f335855'}},y1:{ticks:{color:'#f2a93c88',font:{size:10},callback:v=>v+'%'},grid:{display:false},position:'right'}}}});
}
function buildDonut(pass,susp,doubt,wrong) {
  const ctx=document.getElementById('c-donut'); if(charts.donut) charts.donut.destroy();
  charts.donut=new Chart(ctx,{type:'doughnut',data:{labels:['Pass','Suspect','Doubtful','Wrong'],datasets:[{data:[pass,susp,doubt,wrong],backgroundColor:['#3ecf8e','#f2a93c','#ef7da0','#f25c5c'],borderColor:'#0f1a2e',borderWidth:2}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},cutout:'62%'}});
}
function buildQCMonthChart(monthly) {
  const ctx=document.getElementById('c-qcmonth'); if(charts.qcmonth) charts.qcmonth.destroy();
  charts.qcmonth=new Chart(ctx,{type:'bar',data:{labels:['J','F','M','A','M','J','J','A','S','O','N','D'],datasets:[
    {label:'Pass',data:monthly.map(m=>m.flags[0]),backgroundColor:'#3ecf8e55',borderColor:'#3ecf8e',borderWidth:1},
    {label:'Suspect',data:monthly.map(m=>m.flags[1]),backgroundColor:'#f2a93c55',borderColor:'#f2a93c',borderWidth:1},
    {label:'Doubtful',data:monthly.map(m=>m.flags[2]),backgroundColor:'#ef7da055',borderColor:'#ef7da0',borderWidth:1},
    {label:'Wrong',data:monthly.map(m=>m.flags[3]),backgroundColor:'#f25c5c55',borderColor:'#f25c5c',borderWidth:1},
  ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false}},
    scales:{x:{stacked:true,grid:{display:false},ticks:{color:'#6c84a8',font:{size:10}}},y:{stacked:true,grid:{color:'#1f335855'},ticks:{color:'#6c84a8',font:{size:10}}}}}});
}
function buildFlagBars(pf,n) {
  document.getElementById('flag-bars').innerHTML=Object.entries(pf).sort((a,b)=>b[1]-a[1]).map(([name,cnt])=>{
    const p=(cnt/n*100),max=Object.values(pf).reduce((a,b)=>Math.max(a,b),1);
    const color=p>40?'#f25c5c':p>20?'#ef7da0':p>10?'#f2a93c':'#3ecf8e';
    return`<div class="fb-item"><div class="fb-name">${name}</div><div class="fb-bar-wrap"><div class="fb-bar" style="width:${(cnt/max*100).toFixed(1)}%;background:${color}"></div></div><div class="fb-pct">${p.toFixed(1)}%</div></div>`;
  }).join('');
}
function buildHotspots(pf,n) {
  const colors=['c-red','c-orange','c-yellow','c-teal'];
  const descs={MSL:'Step-change / pressure sensor drift',SLP:'Spike or out-of-range pressure',RH:'Sensor saturation / range issue','Min temp':'Logic violation vs current temp',Temperature:'Range exceedance','Max temp':'Logic violation vs current temp',Rainfall:'Accumulation spike or negative','Wind dir':'Out of 0–360° range','Wind speed':'Exceeds physical max',UV:'Spike above physical maximum'};
  const sorted=Object.entries(pf).filter(([,c])=>c>0).sort((a,b)=>b[1]-a[1]).slice(0,4);
  document.getElementById('hs-grid').innerHTML=sorted.length?sorted.map(([name,cnt],i)=>`<div class="hs-card ${colors[i]||'c-blue'}"><div class="hs-name">${name}</div><div class="hs-val">${(cnt/n*100).toFixed(1)}% flagged</div><div class="hs-desc">${descs[name]||'Anomaly detected'}</div></div>`).join(''):'<div style="font-size:12px;color:var(--text3)">No anomalies 🎉</div>';
}
function buildRecs() {
  const recs=[{icon:'🔧',title:'Sensor calibration',desc:'Recalibrate barometric and RH sensors monthly'},{icon:'💧',title:'RH sensor cleaning',desc:'Clean hygroscopic element after rain events'},{icon:'🌡',title:'Radiation shield',desc:'Inspect shield to eliminate temp bias'},{icon:'⚡',title:'Real-time alerts',desc:'Threshold alarms for flag-3 events'},{icon:'🛠',title:'Preventive maintenance',desc:'Bi-monthly full sensor inspection'},{icon:'📡',title:'Network expansion',desc:'Redundant sensors for cross-validation'}];
  document.getElementById('recs-row').innerHTML=recs.map(r=>`<div class="rec"><div class="rec-icon">${r.icon}</div><div class="rec-title">${r.title}</div><div class="rec-desc">${r.desc}</div></div>`).join('');
}

// ── TABLE ──────────────────────────────────────────────────────────────────
function buildTable() {
  document.getElementById('tbl-head').innerHTML='<tr>'+tblColumns.map(c=>`<th>${c}</th>`).join('')+'</tr>';
  renderTable();
}

function renderTable() {
  const flagF=document.getElementById('flag-filter').value;
  const paramF=document.getElementById('param-filter').value;
  const search=(document.getElementById('search-input').value||'').toLowerCase();
  let rows=allRows;
  if(flagF!=='') rows=rows.filter(r=>String(r.qc_overall)===flagF);
  if(paramF){const map={MSL:'qc_MSL',SLP:'qc_SLP',RH:'qc_RH',Temperature:'qc_Temp','Min temp':'qc_Min','Max temp':'qc_Max',Rainfall:'qc_RF_since_03_UTC','Wind dir':'qc_Wind_Dir','Wind speed':'qc_Wind_Speed',UV:'qc_UV'};const qk=map[paramF];if(qk) rows=rows.filter(r=>(r[qk]||0)>0);}
  if(search) rows=rows.filter(r=>Object.values(r).some(v=>String(v).toLowerCase().includes(search)));
  filteredRows=rows; currentPage=0; renderPage();
}

function renderPage() {
  const rows=filteredRows, total=rows.length;
  const start=currentPage*PAGE_SIZE, end=Math.min(start+PAGE_SIZE,total);

  document.getElementById('tbl-body').innerHTML = rows.slice(start,end).map((r, localIdx) => {
    const globalIdx = allRows.indexOf(r);  // actual index in allRows for editing
    return '<tr>' + tblColumns.map(c => {
      const v = r[c];

      // ── QC_OVERALL — clickable pill ──
      if (c === 'qc_overall') {
        const f = v || 0;
        const manualMark = r.__manual ? '<span class="manual-badge">edited</span>' : '';
        return `<td class="flag-cell" onclick="openDropdown(event, ${globalIdx}, 'qc_overall')">
          <span class="pill ${PILL_CLS[f]}">${PILL_LBL[f]}</span>${manualMark}
        </td>`;
      }

      // ── Individual QC columns — clickable number ──
      if (QC_COLS.has(c)) {
        const f = v || 0;
        return `<td class="flag-cell ${FLAG_CLS[f]} qc-num" onclick="openDropdown(event, ${globalIdx}, '${c}')">${f}</td>`;
      }

      // ── Normal data column ──
      return `<td>${v ?? '—'}</td>`;
    }).join('') + '</tr>';
  }).join('');

  document.getElementById('tbl-info').textContent=`Showing ${total?start+1:0}–${end} of ${total.toLocaleString()} records`;
  const pages=Math.ceil(total/PAGE_SIZE), pb=document.getElementById('page-btns');
  pb.innerHTML='';
  const btn=(lbl,pg,dis,act)=>{const b=document.createElement('button');b.className='page-btn'+(act?' active':'');b.textContent=lbl;b.disabled=dis;b.onclick=()=>{currentPage=pg;renderPage();};pb.appendChild(b);};
  btn('‹',currentPage-1,currentPage===0);
  for(let i=Math.max(0,currentPage-2);i<Math.min(pages,currentPage+3);i++) btn(i+1,i,false,i===currentPage);
  btn('›',currentPage+1,currentPage>=pages-1);
}

// ── INLINE FLAG EDITOR ─────────────────────────────────────────────────────
let openDropdownEl = null;

function openDropdown(event, rowIdx, colName) {
  event.stopPropagation();

  // close any existing dropdown
  if (openDropdownEl) { openDropdownEl.remove(); openDropdownEl = null; }

  const cell = event.currentTarget;
  const currentVal = allRows[rowIdx][colName] || 0;

  const dd = document.createElement('div');
  dd.className = 'flag-dropdown';
  dd.innerHTML = `
    <div style="font-size:10px;color:var(--text3);padding:4px 8px 6px;font-family:'Inter',sans-serif;font-weight:600;text-transform:uppercase;letter-spacing:.05em">
      Change "${colName.replace('qc_','').replace(/_/g,' ')}" flag
    </div>
    ${[0,1,2,3].map(f => `
      <button class="fd-${f}${f===currentVal?' fd-active':''}"
        onclick="applyFlag(event,${rowIdx},'${colName}',${f})">
        ${FLAG_LBL[f]}${f===currentVal?' ← current':''}
      </button>`).join('')}
    <button class="fd-cancel" onclick="closeDropdown(event)">Cancel</button>
  `;

  cell.style.position = 'relative';
  cell.appendChild(dd);
  openDropdownEl = dd;

  // close when clicking elsewhere
  setTimeout(() => document.addEventListener('click', closeOnOutside), 10);
}

function closeOnOutside(e) {
  if (openDropdownEl && !openDropdownEl.contains(e.target)) {
    openDropdownEl.remove(); openDropdownEl = null;
    document.removeEventListener('click', closeOnOutside);
  }
}

function closeDropdown(e) {
  e.stopPropagation();
  if (openDropdownEl) { openDropdownEl.remove(); openDropdownEl = null; }
  document.removeEventListener('click', closeOnOutside);
}

function applyFlag(event, rowIdx, colName, newFlag) {
  event.stopPropagation();

  const row = allRows[rowIdx];
  const oldVal = row[colName];
  if (oldVal === newFlag) { closeDropdown(event); return; }

  row[colName] = newFlag;

  // If editing qc_overall directly, mark as manual
  // If editing a sub-column, recompute qc_overall from all QC cols
  if (colName !== 'qc_overall') {
    const allQcCols = ['qc_MSL','qc_Battery','qc_RF_since_03_UTC','qc_Temp',
                       'qc_Min','qc_Max','qc_RH','qc_Wind_Dir','qc_Wind_Speed','qc_SLP','qc_UV'];
    row.qc_overall = Math.max(...allQcCols.map(c => row[c] || 0));
  }

  // Track manual edit
  if (!row.__manual) { row.__manual = true; manualEdits++; }

  closeDropdown(event);
  renderPage();
  updateManualBadge();
  showToast(`✏️ Row ${rowIdx+1}: ${colName.replace('qc_','')} → ${PILL_LBL[newFlag]}`);
}

function updateManualBadge() {
  const btn = document.getElementById('manual-count-btn');
  document.getElementById('manual-count').textContent = manualEdits;
  btn.style.display = manualEdits > 0 ? 'inline-flex' : 'none';
}

function scrollToTable() {
  document.getElementById('table-panel').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── DOWNLOAD (includes manual edits) ──────────────────────────────────────
function downloadQC() {
  if (!allRows.length) { showToast('No data to download', true); return; }

  // Build CSV from allRows (includes any manual edits)
  const cols = tblColumns.filter(c => c !== '__manual'); // exclude internal flag
  const header = cols.join(',');
  const body = allRows.map(r =>
    cols.map(c => {
      const v = r[c] ?? '';
      // quote values that contain commas or quotes
      return String(v).includes(',') || String(v).includes('"')
        ? '"' + String(v).replace(/"/g,'""') + '"'
        : v;
    }).join(',')
  ).join('\n');
  const csv = header + '\n' + body;

  const blob = new Blob([csv], {type:'text/csv'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = fileName + '_qc_output.csv';
  a.click();
  showToast('✓ Downloaded with ' + (manualEdits > 0 ? manualEdits + ' manual edits included' : 'all QC flags'));
}

// ── RESET ──────────────────────────────────────────────────────────────────
function resetApp() {
  currentJobId=null; allRows=[]; filteredRows=[]; manualEdits=0;
  document.getElementById('dashboard').style.display='none';
  document.getElementById('progress-section').style.display='none';
  document.getElementById('upload-section').style.display='flex';
  document.getElementById('manual-count-btn').style.display='none';
  fileInput.value='';
  for(let i=1;i<=6;i++){const el=document.getElementById('s'+i);el.classList.remove('done','active');el.querySelector('.step-icon').textContent=i;if(i===1)el.classList.add('active');}
  document.getElementById('prog-bar').style.width='0%';
}

// ── UTILS ──────────────────────────────────────────────────────────────────
const delay = ms => new Promise(r=>setTimeout(r,ms));
const pct   = (a,b) => b?(a/b*100).toFixed(1)+'%':'—';
const setText = (id,v) => { const el=document.getElementById(id); if(el) el.textContent=v??'—'; };
function showToast(msg, isErr=false) {
  const t=document.getElementById('toast');
  t.textContent=msg; t.className='toast'+(isErr?' err-toast':'')+' show';
  setTimeout(()=>t.classList.remove('show'),3000);
}