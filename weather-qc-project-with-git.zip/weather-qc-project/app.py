"""
Weather QC Anomaly Detection — FastAPI Backend
Run with:  uvicorn app:app --reload --port 8000
Then open: http://127.0.0.1:8000
"""

import io
import os
import uuid
import re
from datetime import datetime

import pandas as pd
import numpy as np
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware

# ──────────────────────────────────────────────────────────────────────────
# APP SETUP
# ──────────────────────────────────────────────────────────────────────────
app = FastAPI(title="Weather QC Anomaly Detection API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# In-memory store: job_id -> result dict (qc dataframe path + dashboard json)
JOBS = {}


# ──────────────────────────────────────────────────────────────────────────
# COLUMN AUTO-DETECTION
# ──────────────────────────────────────────────────────────────────────────
def normalize(name: str) -> str:
    return re.sub(r"[\s_()]", "", str(name)).lower()


def find_col(columns, *terms):
    norm_map = {normalize(c): c for c in columns}
    for term in terms:
        t = normalize(term)
        for norm_name, original in norm_map.items():
            if t in norm_name:
                return original
    return None


def detect_columns(df: pd.DataFrame) -> dict:
    cols = df.columns.tolist()
    return {
        "date": find_col(cols, "date") or cols[0],
        "time": find_col(cols, "time"),
        "station_code": find_col(cols, "stationcode", "station code"),
        "station_name": find_col(cols, "stationname", "station name"),
        "lat": find_col(cols, "lat"),
        "lon": find_col(cols, "long", "lon"),
        "msl": find_col(cols, "msl"),
        "battery": find_col(cols, "battery", "batt"),
        "rf": find_col(cols, "rfsince", "rf(since", "rainfall"),
        "temp": find_col(cols, "temp"),
        "min": find_col(cols, "min"),
        "max": find_col(cols, "max"),
        "rh": find_col(cols, "rh", "humidity"),
        "wdir": find_col(cols, "winddir", "wind dir"),
        "wspd": find_col(cols, "windspeed", "wind speed"),
        "slp": find_col(cols, "slp"),
        "uv": find_col(cols, "uvindex", "uv index", "uv"),
    }


def to_numeric(series):
    if series is None:
        return None
    return pd.to_numeric(series, errors="coerce")


# ──────────────────────────────────────────────────────────────────────────
# QC ENGINE  (mirrors the rules used in aws_qc_output.csv)
# ──────────────────────────────────────────────────────────────────────────
def run_qc(df: pd.DataFrame, col: dict) -> pd.DataFrame:
    out = df.copy()

    msl = to_numeric(df[col["msl"]]) if col["msl"] else None
    temp = to_numeric(df[col["temp"]]) if col["temp"] else None
    min_t = to_numeric(df[col["min"]]) if col["min"] else None
    max_t = to_numeric(df[col["max"]]) if col["max"] else None
    rh = to_numeric(df[col["rh"]]) if col["rh"] else None
    wdir = to_numeric(df[col["wdir"]]) if col["wdir"] else None
    wspd = to_numeric(df[col["wspd"]]) if col["wspd"] else None
    slp = to_numeric(df[col["slp"]]) if col["slp"] else None
    rf = to_numeric(df[col["rf"]]) if col["rf"] else None
    uv = to_numeric(df[col["uv"]]) if col["uv"] else None

    n = len(df)
    zeros = pd.Series(np.zeros(n, dtype=int))

    # ── MSL: step-change detection ──
    if msl is not None:
        diff = msl.diff().abs()
        qc_msl = pd.Series(0, index=df.index)
        qc_msl[diff > 3] = 1
        qc_msl[diff > 6] = 2
        qc_msl = qc_msl.fillna(0).astype(int)
    else:
        qc_msl = zeros.copy()

    # ── Battery: always pass (no observed failure mode) ──
    qc_battery = zeros.copy()

    # ── Rainfall: range check ──
    if rf is not None:
        qc_rf = pd.Series(0, index=df.index)
        qc_rf[rf > 50000] = 1
        qc_rf[rf > 100000] = 2
        qc_rf[rf < 0] = 3
        qc_rf = qc_rf.fillna(0).astype(int)
    else:
        qc_rf = zeros.copy()

    # ── Temperature: WMO-style range bounds ──
    if temp is not None:
        qc_temp = pd.Series(0, index=df.index)
        qc_temp[(temp < 0) | (temp > 40)] = 1
        qc_temp[(temp < -10) | (temp > 45)] = 2
        qc_temp[(temp < -40) | (temp > 55)] = 3
        qc_temp = qc_temp.fillna(0).astype(int)
    else:
        qc_temp = zeros.copy()

    # ── Min temp: logical consistency vs current temp ──
    if min_t is not None and temp is not None:
        qc_min = pd.Series(0, index=df.index)
        qc_min[min_t > (temp + 0.5)] = 2
        qc_min[(min_t < -40) | (min_t > 55)] = 3
        qc_min = qc_min.fillna(0).astype(int)
    else:
        qc_min = zeros.copy()

    # ── Max temp: logical consistency vs current temp ──
    if max_t is not None and temp is not None:
        qc_max = pd.Series(0, index=df.index)
        qc_max[max_t < (temp - 0.5)] = 2
        qc_max[max_t > 55] = 3
        qc_max = qc_max.fillna(0).astype(int)
    else:
        qc_max = zeros.copy()

    # ── RH: saturation / range check ──
    if rh is not None:
        qc_rh = pd.Series(0, index=df.index)
        qc_rh[rh >= 95] = 1
        qc_rh[(rh < 0) | (rh > 100)] = 3
        qc_rh = qc_rh.fillna(0).astype(int)
    else:
        qc_rh = zeros.copy()

    # ── Wind direction: 0-360 range ──
    if wdir is not None:
        qc_wdir = pd.Series(0, index=df.index)
        qc_wdir[(wdir < 0) | (wdir > 360)] = 2
        qc_wdir = qc_wdir.fillna(0).astype(int)
    else:
        qc_wdir = zeros.copy()

    # ── Wind speed: physical max check ──
    if wspd is not None:
        qc_wspd = pd.Series(0, index=df.index)
        qc_wspd[(wspd < 0) | (wspd > 75)] = 1
        qc_wspd = qc_wspd.fillna(0).astype(int)
    else:
        qc_wspd = zeros.copy()

    # ── SLP: absolute range + spike detection ──
    if slp is not None:
        diff_slp = slp.diff().abs()
        qc_slp = pd.Series(0, index=df.index)
        qc_slp[(slp < 800) | (slp > 1100)] = 2
        qc_slp[diff_slp > 5] = 2
        qc_slp = qc_slp.fillna(0).astype(int)
    else:
        qc_slp = zeros.copy()

    # ── UV index: physical maximum spike check ──
    if uv is not None:
        qc_uv = pd.Series(0, index=df.index)
        qc_uv[uv > 11] = 1
        qc_uv[uv > 20] = 2
        qc_uv = qc_uv.fillna(0).astype(int)
    else:
        qc_uv = zeros.copy()

    out["qc_MSL"] = qc_msl
    out["qc_Battery"] = qc_battery
    out["qc_RF_since_03_UTC"] = qc_rf
    out["qc_Temp"] = qc_temp
    out["qc_Min"] = qc_min
    out["qc_Max"] = qc_max
    out["qc_RH"] = qc_rh
    out["qc_Wind_Dir"] = qc_wdir
    out["qc_Wind_Speed"] = qc_wspd
    out["qc_SLP"] = qc_slp
    out["qc_UV"] = qc_uv

    qc_cols = ["qc_MSL", "qc_Battery", "qc_RF_since_03_UTC", "qc_Temp", "qc_Min",
               "qc_Max", "qc_RH", "qc_Wind_Dir", "qc_Wind_Speed", "qc_SLP", "qc_UV"]
    out["qc_overall"] = out[qc_cols].max(axis=1)

    return out

#dashboard 
def build_dashboard(qc: pd.DataFrame, col: dict) -> dict:
    n = len(qc)
    flag_counts = qc["qc_overall"].value_counts().reindex([0, 1, 2, 3], fill_value=0)

    param_cols = {
        "MSL": "qc_MSL", "SLP": "qc_SLP", "Min temp": "qc_Min", "RH": "qc_RH",
        "Temperature": "qc_Temp", "Max temp": "qc_Max", "Rainfall": "qc_RF_since_03_UTC",
        "Wind dir": "qc_Wind_Dir", "Wind speed": "qc_Wind_Speed", "UV": "qc_UV",
    }
    param_flags = {name: int((qc[c] > 0).sum()) for name, c in param_cols.items()}
    worst = max(param_flags.items(), key=lambda x: x[1]) if param_flags else ("—", 0)

    # ────────────────────────────────────────────────────────────────────────
    # DYNAMIC MULTI-YEAR TRACKING (IN PYTHON)
    # ────────────────────────────────────────────────────────────────────────
    monthly = []
    
    if col["date"]:
        try:
            # Parse dates safely
            dt = pd.to_datetime(qc[col["date"]], dayfirst=True, errors="coerce")
        except Exception:
            dt = pd.Series([pd.NaT] * n)
        
        qc["_year"] = dt.dt.year
        qc["_month"] = dt.dt.month

        # Find the unique years present in the uploaded file
        unique_years = sorted([int(y) for y in qc["_year"].dropna().unique()])
        month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

        # Loop chronologically through years and months
        for year in unique_years:
            for m in range(1, 13):
                sub = qc[(qc["_year"] == year) & (qc["_month"] == m)]
                
                # Only include the month if it actually has data records
                if len(sub) > 0:
                    temp_avg = float(to_numeric(sub[col["temp"]]).mean()) if col["temp"] else None
                    rh_avg = float(to_numeric(sub[col["rh"]]).mean()) if col["rh"] else None
                    flags = sub["qc_overall"].value_counts().reindex([0, 1, 2, 3], fill_value=0).tolist()
                    
                    # If data spans multiple years, label it "2024-Jan", otherwise just "Jan"
                    label_suffix = f"{year}-{month_names[m-1]}" if len(unique_years) > 1 else month_names[m-1]

                    monthly.append({
                        "month": label_suffix,  # Sends the clear year designation straight to the graph label
                        "avg_temp": round(temp_avg, 2) if temp_avg is not None and not np.isnan(temp_avg) else None,
                        "avg_rh": round(rh_avg, 2) if rh_avg is not None and not np.isnan(rh_avg) else None,
                        "flags": [int(x) for x in flags],
                    })
                    
        # Remove structural columns safely
        qc.drop(columns=["_year", "_month"], errors="ignore", inplace=True)

    dates = qc[col["date"]].dropna().astype(str) if col["date"] else pd.Series([])
    period = f"{dates.iloc[0]} → {dates.iloc[-1]}" if len(dates) else ""
    station_name = str(qc[col["station_name"]].iloc[0]) if col["station_name"] else "Station"

    return {
        "station_name": station_name,
        "period": period,
        "total": n,
        "pass": int(flag_counts[0]),
        "suspect": int(flag_counts[1]),
        "doubtful": int(flag_counts[2]),
        "wrong": int(flag_counts[3]),
        "worst_param": worst[0],
        "worst_param_count": worst[1],
        "param_flags": param_flags,
        "monthly": monthly,  # Remains fully backwards-compatible with your HTML JavaScript loops!
    }


# ──────────────────────────────────────────────────────────────────────────
# ROUTES
# ──────────────────────────────────────────────────────────────────────────
@app.post("/api/analyze")
async def analyze(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(".csv"):
        raise HTTPException(status_code=400, detail="Please upload a .csv file")

    raw_bytes = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(raw_bytes))
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Could not parse CSV: {e}")

    # Drop fully-empty "Unnamed" columns often produced by Excel exports
    df = df.loc[:, ~df.columns.str.contains(r"^Unnamed", na=False) | df.notna().any()]

    col = detect_columns(df)
    qc_df = run_qc(df, col)
    dashboard = build_dashboard(qc_df, col)

    job_id = str(uuid.uuid4())[:8]
    out_name = f"{os.path.splitext(file.filename)[0]}_qc_output_{job_id}.csv"
    out_path = os.path.join(OUTPUT_DIR, out_name)
    qc_df.to_csv(out_path, index=False)

    JOBS[job_id] = {"csv_path": out_path, "filename": out_name}

    # table preview: first 500 rows, NaN-safe
    preview_cols = [c for c in [col["date"], col["time"], col["temp"], col["rh"],
                                 col["wspd"], col["msl"], col["slp"]] if c] + \
                    ["qc_MSL", "qc_Battery", "qc_RF_since_03_UTC", "qc_Temp", "qc_Min",
                     "qc_Max", "qc_RH", "qc_Wind_Dir", "qc_Wind_Speed", "qc_SLP", "qc_UV", "qc_overall"]
    table_df = qc_df[preview_cols].replace({np.nan: None})
    table_records = table_df.to_dict(orient="records")

    return JSONResponse({
        "job_id": job_id,
        "columns": preview_cols,
        "dashboard": dashboard,
        "rows": table_records,
    })


@app.get("/api/download/{job_id}")
async def download(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found. Re-upload the file.")
    return FileResponse(job["csv_path"], filename=job["filename"], media_type="text/csv")


@app.get("/api/health")
async def health():
    return {"status": "ok", "time": datetime.utcnow().isoformat()}


# ──────────────────────────────────────────────────────────────────────────
# SERVE FRONTEND (static/index.html)
# ──────────────────────────────────────────────────────────────────────────
app.mount("/", StaticFiles(directory=os.path.join(BASE_DIR, "static"), html=True), name="static")